package edu.metrostate.ics.macrogroceryguide.model;

public class Config {

    public static  final String SPREADHSEET_ID = "1Ed_B8v0ZVNtstaj9Eec6iViBEe3IxBWElJU3uSuFPYY";
    public static final String API_KEY = "AIzaSyDbZXhsyhb--iKJPnSF5NhgeOHhwQudsps";

    //google app script links : returns formatted JSON object
    public static final String PROTEIN_JSON_URL = "https://script.google.com/" +
            "macros/s/AKfycbwm3Be3Zp90aj2yrpwGyEVCbfrqYD4xp3RVQlY7HeFrhjJoAQcH/exec";
    public static final String FATS_JSON_URL = "https://script.google.com/" +
            "macros/s/AKfycbyhF5i5cau9b2ODnMcFY3gw-HDpUZxkMGkb7V3f1lttUUdzpVE/exec";
    public static final String CARBS_JSON_URL = "https://script.google.com/" +
            "macros/s/AKfycbz9GdN7fn3q9wAmlU7UOf2kE0oceKQlkmPAA-uChPZgHiEBBpA/exec";

}
